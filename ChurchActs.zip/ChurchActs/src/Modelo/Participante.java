package Modelo;
import java.util.*;

public class Participante extends Persona {

	HashMap gustosPorTipoReunion;
	HashMap gustosPorFechaReunion;
	HashMap gustosPorPastorReunion;
	
	public Participante(int id, String nombre, String apellido) {
		super(id, nombre, apellido);
		
	}
}
