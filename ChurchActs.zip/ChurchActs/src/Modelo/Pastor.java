package Modelo;

public class Pastor extends Persona {
	
	public float costo;
	
	public Pastor(int id, String nombre, String apellido, float costo) {
		super(id, nombre, apellido);
		this.costo = costo;
	}

}
