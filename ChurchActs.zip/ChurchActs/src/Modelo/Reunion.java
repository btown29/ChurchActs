package Modelo;
import com.mindfusion.common.DateTime;
import java.util.*;


public class Reunion {
	
	public DateTime fechaInicio;
	public DateTime fechaTermino;
	public float costos;
	public float ingresos;
	public String tipoDeReunion;
	public ArrayList <Participante> participantes;
	public Pastor pastor;
	public int capacidad;
	
	public Reunion(DateTime fechaInicio, DateTime fechaTermino, float costos , float ingresos , String tipoDeReunion,
		       Pastor pastor,ArrayList <Participante> participantes,int capacidad){
		
		this.fechaInicio = fechaInicio;
		this.fechaTermino = fechaTermino;
		this.costos = costos;
		this.ingresos = ingresos;
		this.participantes = participantes;
		this.pastor = pastor;
		this.capacidad = capacidad;
		this.tipoDeReunion = tipoDeReunion;
		
	}
	
	public String toString() {
		return ("Fecha: " +fechaInicio.getDay()+"/"+fechaInicio.getMonth() +"                 Hora de Inicio: "+ fechaInicio.getHour() + ":"
				+ fechaInicio.getMinute() + "                  Hora de Termino: "+ fechaTermino.getHour() + ":" +fechaTermino.getMinute() +
				"                Tipo de Reunion: "+ tipoDeReunion + "               Beneficios: $" + (ingresos - costos) + "\n\n" );
	}
	
	
	

}
