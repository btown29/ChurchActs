package Modelo;
import java.util.*;

public class Persona{

	public int id;
	public String nombre;
	public String apellido;

	public Persona(int id, String nombre, String apellido){
		this.id = id;
		this.nombre = nombre;
		this.apellido = apellido;
	}
}
