package Modelo;
import java.util.*;

import com.mindfusion.common.DateTime;

public class Simulador {

	
	public Simulador() {
		
	}
	
	/*
	 * Crear participante
	 */
	public Participante crearParticipante() {
		int id = (int)(Math.random()*100) + 2;
		Participante participante = new Participante(id, "Juan", "Perez");
		return participante;
	}
	/*
	 * Crear Pastor
	 */
	public Pastor crearPastor() {
		int id = (int)(Math.random()*100) % 2;
	
		if(id == 0) {
			Pastor pastor = new Pastor(0,"Juan","Soto",30000);
			return pastor;
		}
		else {
			Pastor pastor = new Pastor(1, "Jesus", "Retamal",10000);
			return pastor;
		}
	}
	/*
	 * Crear Reunion
	 */
	public Reunion crearReunion() {
		
		
		int dia = ((int)(Math.random()*100)) % 7 + 15;
		int hora = ((int)(Math.random()*100)) % 23;
		int duracion =1 + (((int)(Math.random()*100)) % 5);
		int capacidad = 100;
		float costos = 0;
		System.out.println(dia + " " + hora + " " + duracion);
		if(hora + duracion > 23) {duracion = 1;}
		DateTime fechaInicio = new DateTime(2019,7,dia,hora,0,0);
		DateTime fechaTermino = new DateTime(2019,7,dia,hora + duracion,0,0);
		int seleccionarTipo = (int)(Math.random()*100) % 3;
		Pastor pastor;
		String tipoDeReunion;
		if(seleccionarTipo == 0) {
			tipoDeReunion = "Catequesis";
			pastor = crearPastor();
			capacidad = 20;
			costos = 10000 + pastor.costo;
		}
		if(seleccionarTipo == 1) {
			tipoDeReunion = "Dia de la Virgen María";
			pastor = crearPastor();
			capacidad = 20;
			costos = 10000 + pastor.costo;
		}
		else {
			tipoDeReunion = "Invitación a Bautizo";
			pastor = crearPastor();
			capacidad = 30;
			costos = 15000 + pastor.costo;
			
		}
		ArrayList <Participante> participantes = new ArrayList <Participante>();
		
		for(int i=0;i < capacidad; i++) {
			participantes.add(crearParticipante());
		}
		// Falta calcular los ingresos
		float ingresos = 80000;
		Reunion reunion = new Reunion(fechaInicio, fechaTermino, costos , ingresos , tipoDeReunion,
			       pastor,participantes,capacidad);
		return reunion;
		
	}
	public ArrayList<Reunion> crearListaDeReuniones(int numero){
		ArrayList<Reunion> lista = new ArrayList<Reunion>();
		for(int i=0; i < numero; i++) {
			lista.add(crearReunion());
		}
		return lista;
	}
	
	public void mostrarListaReuniones(ArrayList<Reunion>reuniones) {
		System.out.println(reuniones.toString());
	}
	
	public void ordenarPorBeneficios(ArrayList<Reunion> reuniones) {
		Collections.sort(reuniones, new Comparator<Reunion>() {
			public int compare(Reunion r1, Reunion r2) {
				return Float.valueOf(r2.ingresos - r2.costos).compareTo(r1.ingresos-r1.costos);
			}
		});	
	}
	public ArrayList<Reunion> greedy(ArrayList<Reunion> reuniones){
		ArrayList<Reunion> eventos = new ArrayList<Reunion>();
		eventos.add(reuniones.get(0));
		boolean posibleInsertar = true;
		for(int i = 1; i < reuniones.size(); i++) {
			for(int j = 0; j< eventos.size();j++) {
				if(reuniones.get(i).fechaInicio.getDay() == eventos.get(j).fechaInicio.getDay()) {
					if(reuniones.get(i).fechaInicio.getHour() < eventos.get(j).fechaTermino.getHour() && eventos.get(j).fechaInicio.getHour() < reuniones.get(i).fechaTermino.getHour()) {
					posibleInsertar = false;
					}
				}
			}
			if(posibleInsertar) {
				eventos.add(reuniones.get(i));
			}
			else {
				posibleInsertar = true;
			}
		}
		return eventos;
		
	}
	
		
}
