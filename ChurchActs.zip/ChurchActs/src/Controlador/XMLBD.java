
package Controlador;

/**
 *
 * @author Diego
 */
public class XMLBD {
    public static void main (String[] args) {
       
    }
}
