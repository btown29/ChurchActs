
package Controlador;

import Vista.VentanaIntermedia;
import Vista.VentanaLogin;
import Vista.VentanaUsuario;
import googleCalendar.Organizador;



public class ClaseEjecutable {
     public static void main (String[] args) {
        VentanaLogin ventana = new VentanaLogin();
        VentanaIntermedia ventana1 = new VentanaIntermedia();
        //Organizador ventana2 = new Organizador();
        VentanaUsuario ventana3 = new VentanaUsuario();
     }
}
