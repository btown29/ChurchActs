package Vista;
import Modelo.*;
import googleCalendar.MainWindow;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;

import javax.swing.border.EmptyBorder;
import javax.swing.*;
import java.util.*;

public class VentanaSimulacion extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					//VentanaSimulacion frame = new VentanaSimulacion(1);
					//frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaSimulacion(int numero,ArrayList<Reunion>reuniones,ArrayList<Reunion>reuniones2) {
        super("Reuniones Simuladas");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JLabel tf = new JLabel("         Número de reuniones :  " + numero +"                                                                                                                                                                                     Luego de aplicar Greedy: "+reuniones2.size());
        add(tf, BorderLayout.NORTH);
        JTextArea ta = new JTextArea(50, 60);
        JScrollPane ja = new JScrollPane(ta);
        JTextArea tb = new JTextArea(50,60);
        JScrollPane jb = new JScrollPane(tb);
        JPanel JPanelArea = new JPanel();
        JPanelArea.add(ja);
        JPanelArea.add(jb);
        add(ja, BorderLayout.WEST);
        add(jb, BorderLayout.EAST);
        JPanel panel = new JPanel();
        JButton button1 = new JButton("Siguiente");
        button1.addActionListener(new ActionListener() { 
    	   public void actionPerformed(ActionEvent e) { 
    		   setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    		   
    	   } 
    	 } );
        panel.add(button1);
        add(panel, BorderLayout.SOUTH);
        String texto = " ";
        String texto1 = " ";
        for(Reunion reunion: reuniones) {
        	texto = texto +(reunion.toString());      	
        }
        ta.setText(texto);
        for(Reunion reunion: reuniones2) {
        	texto1 = texto1 +(reunion.toString());      	
        }
        tb.setText(texto1);
        //pack();
        // arbitrary size to make vertical scrollbar appear
        setSize(1400, 900);
        //setLocationByPlatform(true);
        setVisible(true);
	}

}
