package googleCalendar;

import java.awt.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTabbedPane;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.GridLayout;

public class Organizador extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					//new MainWindow();
					Organizador frame = new Organizador();
					//frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Organizador() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 706, 450, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnOptimizarActividades = new JButton("Optimizar Actividades");
		btnOptimizarActividades.setBounds(5, 570, 440, 25);
		//btnOptimizarActividades.addActionListener(new ActionListener() {
			//public void actionPerformed(ActionEvent e) {
				//new MainWindow();
			//}
		//});
		contentPane.setLayout(null);
		contentPane.add(btnOptimizarActividades);
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.setBounds(0, 0, 0, 0);
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		
		JLabel label = new JLabel("");
		label.setBounds(0, 0, 0, 0);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(0, 0, 0, 0);
		contentPane.add(label_1);
		
		JLabel lblReuniones = new JLabel("Reuniones");
		lblReuniones.setBounds(5, 5, 440, 15);
		contentPane.add(lblReuniones);
		contentPane.add(btnVolver);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(5, 20, 440, 550);
		contentPane.add(tabbedPane);
		
		JScrollPane scrollPane = new JScrollPane();
		tabbedPane.addTab("New tab", null, scrollPane, null);
	}
}
